/* --------------------------------------------------------------------------------------------
 * Copyright (c) Microsoft Corporation. All rights reserved.
 * Licensed under the MIT License. See License.txt in the project root for license information.
 * ------------------------------------------------------------------------------------------ */
'use strict';

const LanguageServer = require("vscode-languageserver");
//TODO turn this into a lib that can be installed via npm
const CdxWrapper = require("../../cdx-wrapper/lib/cdx_wrapper");

// can be Full or Incremental. Full always sends the full content for each change. 
// Incremental only sends the changes. Incremental requires to cache the content on server
// side so that the changes can be merged into the original content. Incremental is pretty untested and experimental.
// !!!!!!!!!!!!!Requires some uncommenting and commenting in code below!!!!!!!!!!!!!
const documentSyncMode = LanguageServer.TextDocumentSyncKind.Full;

// Create a connection for the server. The connection uses Node's IPC as a transport
let connection = LanguageServer.createConnection();

// Create a simple text document manager. The text document manager
// supports full document sync only
let documents = new LanguageServer.TextDocuments();

// After the server has started the client sends an initialize request. The server receives
// in the passed params the rootPath of the workspace plus the client capabilities. 
let workspaceRoot;

// hold the maxNumberOfProblems setting
let maxNumberOfProblems;

connection.onInitialize((params) => {
    workspaceRoot = params.rootPath;
    return {
        capabilities: {
            // Tell the client that the server works in FULL text document sync mode
            // It is also possible to use the Incremental mode here, 
            textDocumentSync: documentSyncMode,
            // Tell the client that the server support code completion
            completionProvider: {
                resolveProvider: true,
            },
        }
    };
});

//needs to be commented when using incremental
documents.onDidChangeContent((change) => {
    console.log("onDidChangeContent");
    validateDocument(change.document, change.document.uri);
});

connection.onDidChangeConfiguration((change) => {
    console.log("onDidChangeConfiguration");
    let settings = change.settings;
    maxNumberOfProblems = settings.languageServerExample.maxNumberOfProblems || 100;
    // Revalidate any open text documents
    documents.all().forEach(function (doc) {
        validateDocument(doc, doc.uri);
    });
});

/**
 * Validates the content of the file and checks for errors
 * @param {*} textDocument Document
 */
function validateDocument(textDocument, fileName) {
    let diagnostics = [];
    let content;
    if (documentSyncMode === LanguageServer.TextDocumentSyncKind.Incremental) {
        content = textDocument.text;
    } else if (documentSyncMode === LanguageServer.TextDocumentSyncKind.Full) {
        content = textDocument.getText();
    }

    let messages = CdxWrapper.getMessages(content, fileName);

    messages.forEach(function (message) {
        let msg = message.toString();

        if (msg.startsWith("Error")) {
            diagnostics.push({
                severity: LanguageServer.DiagnosticSeverity.Error,
                range: {
                    start: { line: message.location.start.line - 1, character: message.location.start.column - 1 },
                    end: { line: message.location.end.line - 1, character: message.location.end.column - 1 }
                },
                message: message.toString(),
                source: 'cdx'
            });
        } else {
            console.log("Unknwon message: " + msg);
        }
    });

    // Send the computed diagnostics to the client.*/
    connection.sendDiagnostics({ uri: textDocument.uri, diagnostics });
}

connection.onDidChangeWatchedFiles((change) => {
    // Monitored files have change in VSCode
    connection.console.log('We received a file change event');
});

// This handler provides the initial list of the completion items.
connection.onCompletion((textDocumentPosition) => {
    let content;
    if (documentSyncMode === LanguageServer.TextDocumentSyncKind.Incremental) {
        content = documents._documents[textDocumentPosition.textDocument.uri].text;
    } else if (documentSyncMode === LanguageServer.TextDocumentSyncKind.Full) {
        content = documents.get(textDocumentPosition.textDocument.uri).getText();
    }

    let expectedTokens = CdxWrapper.getExpectedTokens(content, textDocumentPosition.textDocument.uri);
    if (expectedTokens.length == 0) {
        expectedTokens = CdxWrapper.getExpectedTokens(replace(textDocumentPosition.position.line, textDocumentPosition.position.line, textDocumentPosition.position.character, textDocumentPosition.position.character, content, "^"), textDocumentPosition.textDocument.uri);
    }

    let completionItems = [];

    for (let i = textDocumentPosition.position.line; i < expectedTokens.length; i++) {
        if (expectedTokens[i]) {
            expectedTokens[i].forEach(function (token, index) {
                if (token) {
                    token = replaceAll(token, "'", "");
                    completionItems.push({
                        label: token,
                        kind: LanguageServer.CompletionItemKind.Text,
                        data: index
                    });
                }
            });
            return completionItems;
        }
    }
});

function replaceAll(str, find, replace) {
    return str.replace(new RegExp(find, 'g'), replace);
}


// This handler resolve additional information for the item selected in
// the completion list.
connection.onCompletionResolve((item) => {
    return null;
});

//needs to be uncommented for incremental mode
/*
    connection.onDidOpenTextDocument((params) => {
        connection.console.log(`${params.textDocument.uri} opened.`);
        // Cache initial content of document for delta changes in change method
        documents._documents[params.textDocument.uri] = params.textDocument;
    });

    connection.onDidChangeTextDocument((params) => {
        connection.console.log(`${params.textDocument.uri} changed: ${JSON.stringify(params.contentChanges)}`);

        let startline = params.contentChanges[0].range.start.line;
        let endline = params.contentChanges[0].range.end.line;
        let startchar = params.contentChanges[0].range.start.character;
        let endchar = params.contentChanges[0].range.end.character;

        // Merge changes to content
        documents._documents[params.textDocument.uri].text = replace(startline, endline, startchar, endchar, documents._documents[params.textDocument.uri].text, params.contentChanges[0].text);

        validateDocument(documents._documents[params.textDocument.uri], params.textDocument.uri);
    });

    connection.onDidCloseTextDocument((params) => {
        // A text document got closed in VSCode.
        // params.textDocument.uri uniquely identifies the document.
        connection.console.log(`${params.textDocument.uri} closed.`);
    });
}*/

/**
 * Replaces text in a string based on position of line and row
 * @param {*} startLine line where to start the replacement
 * @param {*} endLine line where to stop the replacement
 * @param {*} startChar position in the start line where the replace should start
 * @param {*} endChar position in the end line where the replace should end
 * @param {*} originalContent content where the replace should be applied to
 * @param {*} changedContent string that should be used to replace part of the original content
 */
function replace(startLine, endLine, startChar, endChar, originalContent, changedContent) {
    //split string into lines
    let nl = originalContent.match(new RegExp("\\n\\r|\\r\\n|\\n"));

    let textArray = [];
    if (nl == null) {
        nl = "";
        textArray[0] = originalContent;
    } else {
        textArray = originalContent.split(nl);
    }

    let newText = "";
    textArray.forEach(function (line, i) {
        if (i < startLine || i > endLine) {
            newText += line;
            //last line does not need newline
            if (i != textArray.length - 1) {
                newText += nl;
            }
        } else if (i === startLine && i === endLine) {
            newText += line.substring(0, startChar) + changedContent + line.substring(endChar, line.length);
            if (i != textArray.length - 1) {
                newText += nl;
            }
        } else if (i === endLine) {
            newText += line.substring(endChar, line.length);
            if (i != textArray.length - 1) {
                newText += nl;
            }
        } else if (i === startLine) {
            newText += line.substring(0, startChar) + changedContent;
        }
    });
    return newText;
}

// Make the text document manager listen on the connection
// for open, change and close text document events
documents.listen(connection);

// Listen on the connection
connection.listen();

exports.replace = replace;
exports.validateDocument = validateDocument;