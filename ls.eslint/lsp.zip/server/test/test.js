var assert = require('assert');
var server = require('../src/server');



describe('Server', function () {
    describe('Replace text in single line', function () {
        it('should return the expected text', function () {
            var text = "Lalalalalala";
            assert.equal("Lblalalalala", server.replace(0, 0, 1, 2, text, "b"));
        });
    });

    describe('Replace single char in text with multiple lines', function () {
        it('should return the expected text', function () {
            var text = `La
lalala
la`;
            assert.equal(`La
lblala
la`, server.replace(1, 1, 1, 2, text, "b"));
        });
    });

    describe('Replace char in text with multiple lines over multiple lines', function () {
        it('should return the expected text', function () {
            var text = `La
lalala
la`;
            assert.equal(`La
lb`, server.replace(1, 2, 1, 2, text, "b"));
        });
    });

    describe('Replace char in text with nl symbols', function () {
        it('should return the expected text', function () {
            var text = `La\nlalala\nla`;
            assert.equal(`La\nlblala\nla`, server.replace(1, 1, 1, 2, text, "b"));
        });
    });

    describe('Replace char in text with nl and cr symbols', function () {
        it('should return the expected text', function () {
            var text = `La\r\nlalala\r\nla`;
            assert.equal(`La\r\nlblala\r\nla`, server.replace(1, 1, 1, 2, text, "b"));
        });
    });

    describe('Replace char in text with nl and cr symbols exchanged', function () {
        it('should return the expected text', function () {
            var text = `La\n\rlalala\n\rla`;
            assert.equal(`La\n\rlblala\n\rla`, server.replace(1, 1, 1, 2, text, "b"));
        });
    });

    describe('Replace text in text with multiple lines', function () {
        it('should return the expected text', function () {
            var text = `Hallo,
dies ist
ein Text.`;
            assert.equal(`Hdein 
 neuer textist
ein Text.`, server.replace(0, 1, 1, 5, text, "dein \n neuer text"));
        });
    });

    describe('Replace char in empty text line', function () {
        it('should return \'b\' charachter instead of empty line', function () {
            var text = '';
            assert.equal('b', server.replace(0, 0, 0, 1, text, 'b'));
        });
    });

});



