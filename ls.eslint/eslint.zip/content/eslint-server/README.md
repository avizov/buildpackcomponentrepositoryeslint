# VSCode ESLint extension - server part

The server part of the VSCode eslint extension.